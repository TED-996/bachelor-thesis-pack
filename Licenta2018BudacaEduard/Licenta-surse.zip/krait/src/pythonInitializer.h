﻿#pragma once
#include <string>

class PythonInitializer {
public:
    PythonInitializer(const std::string& projectRoot);
    ~PythonInitializer();
};
