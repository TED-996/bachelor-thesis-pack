#pragma once
#include <string>

void startCommanderProcess();
void sendCommandClose();
void sendCommandKill();
std::string getCreateDotKrait();
