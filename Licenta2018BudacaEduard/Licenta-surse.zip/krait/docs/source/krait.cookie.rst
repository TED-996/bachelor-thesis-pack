krait\.cookie module
====================

.. automodule:: krait.cookie
    :members:
    :undoc-members:
    :show-inheritance:
