krait\.mvc module
=================

.. automodule:: krait.mvc
    :members:
    :undoc-members:
    :show-inheritance:
