import cycle
import sys


print(sys.argv)