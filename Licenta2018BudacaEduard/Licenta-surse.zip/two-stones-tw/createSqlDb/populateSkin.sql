declare
begin
	insert into skin values(1,1,'Tank');

	insert into skin values(2,2,'Infantry');

	insert into skin values(3,3,'Runner');

	insert into skin values(4,4,'Archer');
end;