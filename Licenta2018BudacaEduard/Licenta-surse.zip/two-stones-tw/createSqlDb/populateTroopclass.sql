begin
  insert into troopclass values (
    1,
    'Tank',
    'Can take a lot of damage.',
    30,
    6,
    2,
    2,
    0
  );
  
  insert into troopclass values (
    2,
    'Infantry',
    'All-rounded soldier.',
    18,
    8,
    2,
    2,
    0
  );
  
  insert into troopclass values (
    3,
    'Runner',
    'Fast, but brittle.',
    10,
    5,
    3,
    4,
    0
  );
  
  insert into troopclass values (
    4,
    'Archer',
    'Can hit far away.',
    12,
    7,
    10,
    2,
    0
  );

end;