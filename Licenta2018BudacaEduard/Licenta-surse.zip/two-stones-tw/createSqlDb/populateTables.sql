start "createTables.sql";

start "./part2/sitePackage.sql";
start "./part2/indexes.sql";
start "./part2/triggers.sql";
start "populateTroopclass.sql";
start "populateModifiers.sql";
start "populateSkin.sql";

commit;