drop trigger onDeletePLayer;
drop trigger onDeleteMap;
drop trigger onDeleteMatch;
drop trigger onDeleteLoadout;
drop trigger onDeleteTroopClass;
drop trigger onDeleteSkin;
drop trigger onDeleteModifier;
drop trigger onDeleteTroop;