begin
  insert into modifier values(
    modifierIdSeq.nextval,
    '20hp+dmg-',
    20,
    -20,
    0,
    0,
    1
  );
  
  insert into modifier values(
    modifierIdSeq.nextval,
    '30hp+dmg-',
    30,
    -30,
    0,
    0,
    2
  );
  
  insert into modifier values(
    modifierIdSeq.nextval,
    '40hp+dmg-',
    40,
    -40,
    0,
    0,
    1
  );
  
  insert into modifier values(
    modifierIdSeq.nextval,
    '20mrng+dmg-',
    0,
    -20,
    0,
    20,
    1
  );
  
    insert into modifier values(
    modifierIdSeq.nextval,
    '30mrng+dmg-',
    0,
    -30,
    0,
    30,
    1
  );  
  
  insert into modifier values(
    modifierIdSeq.nextval,
    '40mrng+dmg-',
    0,
    -40,
    0,
    40,
    1
  );
  
  
  insert into modifier values(
    modifierIdSeq.nextval,
    '20arng+dmg-',
    0,
    -20,
    20,
    0,
    1
  );
  
  insert into modifier values(
    modifierIdSeq.nextval,
    '30arng+dmg-',
    0,
    -30,
    30,
    0,
    1
  );
  
  insert into modifier values(
    modifierIdSeq.nextval,
    '30arng+dmg-',
    0,
    -30,
    30,
    0,
    1
  );
end;