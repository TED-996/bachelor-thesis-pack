from ctrl import register
import mvc

mvc.set_init_ctrl(register.RegisterController())