from ctrl import dashboard
import mvc
mvc.set_init_ctrl(dashboard.DashboardController())

