from ctrl import gameplay
import mvc

mvc.set_init_ctrl(gameplay.GameplayController())