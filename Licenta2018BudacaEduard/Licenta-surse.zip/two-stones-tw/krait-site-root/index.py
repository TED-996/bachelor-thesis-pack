from ctrl import index
import mvc
mvc.set_init_ctrl(index.IndexController())

