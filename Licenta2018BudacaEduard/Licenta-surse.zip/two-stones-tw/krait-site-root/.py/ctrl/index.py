import time
import random

class IndexController(object):
    def __init__(self):
        super(IndexController, self).__init__()
    
    def get_view(self):
        return ".view/index.html"