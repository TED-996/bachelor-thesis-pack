import krait
import mvc

class RegisterFailController(object):
	def __init__(self):
		pass

	def get_view(self):
		return ".view/register_fail.html"
