import krait
import mvc

class LoginController(object):
	def __init__(self):
		pass

	def get_view(self):
		return ".view/login.html"
