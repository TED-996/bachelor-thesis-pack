import krait
import mvc

class RegisterController(object):
	def __init__(self):
		pass

	def get_view(self):
		return ".view/register.html"
