class TroopModifier(object):
    def __init__(self, troop_id, modifier_id):
        self.troop_id = troop_id
        self.modifier_id = modifier_id
