class Skin(object):
    def __init__(self, skinId, class_id, filename):
        self.id = skinId
        self.class_id = class_id
        self.filename = filename