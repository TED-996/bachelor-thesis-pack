 <  ? xml : version = "1.0";
encoding = "UTF-8" ?  >
    <tileset name="hexagonAll_sheet" tilewidth="120" tileheight="140" spacing="2" tilecount="224" columns="16">
 <image source="hexagonAll_sheet.png" width="2048" height="2048"/>
</tileset>
    :
;
