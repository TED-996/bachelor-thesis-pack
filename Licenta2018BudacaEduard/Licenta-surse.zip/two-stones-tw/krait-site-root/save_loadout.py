from ctrl import save_loadout
import krait

krait.response = save_loadout.get_response()