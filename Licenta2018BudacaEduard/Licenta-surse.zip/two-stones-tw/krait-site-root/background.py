from ctrl import background
import mvc
mvc.set_init_ctrl(background.BackgroundController())