from ctrl import get_match_loadout
import mvc
mvc.set_init_ctrl(get_match_loadout.GetMatchLoadoutController())
