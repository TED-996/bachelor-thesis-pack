from ctrl import login_fail
import mvc
mvc.set_init_ctrl(login_fail.LoginFailController())