from ctrl.admin import user_update
import krait

krait.response = user_update.get_response()
