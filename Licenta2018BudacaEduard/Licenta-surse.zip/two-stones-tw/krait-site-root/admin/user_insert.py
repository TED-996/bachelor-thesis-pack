from ctrl.admin import user_insert
import krait

krait.response = user_insert.get_response()
