from ctrl.admin import user_delete
import krait

krait.response = user_delete.get_response()
