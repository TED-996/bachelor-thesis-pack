from ctrl import login
import mvc
mvc.set_init_ctrl(login.LoginController())