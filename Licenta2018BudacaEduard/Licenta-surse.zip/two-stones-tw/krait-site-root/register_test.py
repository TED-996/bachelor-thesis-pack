from ctrl import register_test
import krait

krait.response = register_test.get_response()
