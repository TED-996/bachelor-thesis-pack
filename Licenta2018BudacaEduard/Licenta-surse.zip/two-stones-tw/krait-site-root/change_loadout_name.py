from ctrl import change_loadout_name
import krait
import logging

logging.debug("Got in pagina rutabila change_loadout_name ")
krait.response = change_loadout_name.get_response()