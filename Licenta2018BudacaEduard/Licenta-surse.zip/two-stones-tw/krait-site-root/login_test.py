from ctrl import login_test
import mvc
import krait

krait.response = login_test.get_response()