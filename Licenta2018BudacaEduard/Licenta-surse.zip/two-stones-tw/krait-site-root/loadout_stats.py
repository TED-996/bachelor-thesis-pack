import mvc
from ctrl import loadout_stats

mvc.set_init_ctrl(loadout_stats.LoadoutStatsController())
